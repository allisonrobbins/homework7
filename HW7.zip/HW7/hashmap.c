#include "hashmap.h"

struct hashmap* hm_create(int num_buckets){

}

int hm_get(struct hashmap* hm, char* word, char* document_id){

}

void hm_put(struct hashmap* hm, char* word, char* document_id, int num_occurrences){

}

void hm_destroy(struct hashmap* hm){

}

int hash(struct hashmap* hm, char* word, char* document_id){

}
